package ar.org.centro8.java.curso.cuenta;

import ar.org.centro8.java.curso.banco.Cliente;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class cuentaCorriente extends cuenta {
    private double montoAutorizado;


    public cuentaCorriente(int numeroCuenta, Cliente clienteAsociado, double saldo, double montoAutorizado) {
        super(numeroCuenta, clienteAsociado, saldo);
        this.montoAutorizado = montoAutorizado;
    }

    public void depositarEfectivo(double monto, double saldo){
        if(monto>0) saldo += monto;}

    public boolean despositarCheque(cheque cheque){
        if(cheque.getMonto()<=0) return false;
        setSaldo(getSaldo() + cheque.getMonto());
        return true;
        
    
    }

    public void setSaldo(double d) {
        System.out.printf("el saldo es:", "pesos" , "1000");
    }

    public boolean extraerEfectivo(double monto, double saldo){
        if(monto>0 && monto <= saldo + montoAutorizado){
        saldo -= monto;
        return true;
    }
    return false;//no tiene saldo suficiente ni descubierto
    }

    @Override
    public boolean extraerEfectivo(double monto) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'extraerEfectivo'");
    }





}
