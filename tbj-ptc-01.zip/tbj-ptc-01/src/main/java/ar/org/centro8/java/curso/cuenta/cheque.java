package ar.org.centro8.java.curso.cuenta;

public class cheque {
    private double monto;
    private String bancoEmisor;
    private fechaEmision localDate;
    private int numeroCheque;

    

    
    public cheque(double monto, String bancoEmisor, fechaEmision localDate, int numeroCheque) {
        this.monto = monto;
        this.bancoEmisor = bancoEmisor;
        this.localDate = localDate;
        this.numeroCheque = numeroCheque;
    }


}
