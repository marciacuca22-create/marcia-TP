package ar.org.centro8.java.curso.banco;

import ar.org.centro8.java.curso.cuenta.cajaDeAhorro;
import ar.org.centro8.java.curso.cuenta.cuentaCorriente;

public class testEjercicios {
    public static void main(String[] args) {
        ClienteIndividual Ana = new ClienteIndividual(1, "Ana"," Gomez", "40999888");
        ClienteEmpresa empresa = new ClienteEmpresa(2, "Tech SRL", "30-12345678-9");
        System.out.println("test cliente ok-Individual:"+1+"Empresa:"+2);

        cajaDeAhorro caja = new cajaDeAhorro(5001, ClienteAsociado, 10000, 0.10);
        caja.depositarEfectivo(2000);
        System.out.println("caja despues deposito:"+caja.getSaldo());
        boolean extraercaja1 = caja.extraer(5000);
        System.out.println("caja extraer 5000?"+extraercaja1+"saldo:"+caja.getSaldo());
        boolean extraerCaja2 = caja.extraer(10000);
        System.out.println("2caja extraer 100008(no debe dejar)?"+ extraerCaja2+ "saldo:" +caja.getSaldo());
        caja.cobrarInteres();
        System.out.println("caja con interes:" + caja.getSaldo());

        cuentaCorriente cc = new cuentaCorriente(5002, ana, 10000, 5000);
        cc.depositarEfectivo(1000);
        cc.despositarCheque(2000, 123);
        System.out.println("CC saldo despues depositos:" +cc.getSaldo());
        boolean estraerCC1 = cc.extraer(15000);
        String extraerCC1;
        System.out.println("CC extraer 15000 usando descubierto?"+ extraerCC1+"saldo:" + cc.getSaldo());
        boolean extraerCC2 = cc.extraer(5000);
        System.out.println("CC extraer 5000 mas(se pasa del descubierto?" +extraerCC2+ "SALDO:" + cc.getSaldo());


        String nombreFantasia;
        CuentaConvertibilidad conv = new CuentaConvertibilidad(5003, nombreFantasia, null, 100000, 50000);
        System.out.println("covertibilidad pesos:"+conv.getSaldo()+"dplares:"+ conv.getSaldoDolares());
        conv.convertirPesosADolares(14500);
        System.out.println("depues de convertit 14500 pesos a dolares -> pesos:"+ conv.getSaldo()+"dolares:"+ conv.getSaldoDolares());

        


    }

}
