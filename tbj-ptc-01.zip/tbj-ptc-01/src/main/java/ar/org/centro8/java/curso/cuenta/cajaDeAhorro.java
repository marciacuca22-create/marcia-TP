package ar.org.centro8.java.curso.cuenta;

import ar.org.centro8.java.curso.banco.Cliente;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class cajaDeAhorro extends cuenta {
    private double tasaInteres;
    private double saldo;

    public cajaDeAhorro(int numeroCuenta, Cliente clienteAsociado, double saldo, double tasaInteres) {
        super(numeroCuenta, clienteAsociado, saldo);
        this.tasaInteres = tasaInteres;
    }
    public void depositarEfectivo(double monto){
        if(monto>0) saldo+=monto;}
    public boolean extraerEfectivo(double monto){
        if(monto>0 && monto<=saldo) {
            saldo-=monto;return true;}
            return false;
            
        }
        public void cobrarInteres(){
            saldo += saldo*tasaInteres;
    
    }

    

}
