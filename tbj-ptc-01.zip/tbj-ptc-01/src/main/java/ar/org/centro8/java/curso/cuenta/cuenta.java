package ar.org.centro8.java.curso.cuenta;

import ar.org.centro8.java.curso.banco.Cliente;

public abstract class cuenta {
    private final int numeroCuenta;
    private final Cliente clienteAsociado;
    private double saldo;

    
    public cuenta(int numeroCuenta, Cliente clienteAsociado, double saldo) {
        this.numeroCuenta = numeroCuenta;
        this.clienteAsociado = clienteAsociado;
        this.saldo = saldo;
    }

    public abstract boolean extraerEfectivo(double monto);
    public double getSaldo(){return saldo;}
}
